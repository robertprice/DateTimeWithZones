//>>built
define("dijit/nls/bs/loading",{loadingState:"Učitavanje...",errorState:"Izvinite, došlo je do greške"});
