//>>built
define("dijit/form/nls/mk/ComboBox",{previousMessage:"Претходни избори",nextMessage:"Повеќе избори"});
