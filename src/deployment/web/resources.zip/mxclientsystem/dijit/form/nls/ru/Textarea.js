//>>built
define("dijit/form/nls/ru/Textarea",({iframeEditTitle:"область редактирования",iframeFocusTitle:"фрейм области редактирования"}));
